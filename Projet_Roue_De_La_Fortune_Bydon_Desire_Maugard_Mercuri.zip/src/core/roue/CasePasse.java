package core.roue;

public class CasePasse extends Case{
	
	public CasePasse() {
		super(Valeur.passe);
	}
}
