package core.roue;

public class CaseBanqueRoute extends Case{

	public CaseBanqueRoute() {
		super(Valeur.banqueroute);
	}
}
