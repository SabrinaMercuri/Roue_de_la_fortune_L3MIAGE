package core.roue;

public class CaseHoldUp extends Case{
	
	public CaseHoldUp() {
		super(Valeur.holdUp);
	}

}
